<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class WorkingHour extends Model
{
    use HasFactory;

    protected $fillable = [
        'restaurant_id',
        'day_of_week',
        'open_time',
        'close_time',
        'is_closed',
    ];

    protected $casts = [
        'day_of_week' => 'integer',
        'is_closed' => 'boolean',
    ];

    
    const DAYS = [
        0 => 'Niedziela',
        1 => 'Poniedziałek',
        2 => 'Wtorek',
        3 => 'Środa',
        4 => 'Czwartek',
        5 => 'Piątek',
        6 => 'Sobota',
    ];

    
    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    
    public function scopeOpen($query)
    {
        return $query->where('is_closed', false);
    }

    
    public function scopeForDay($query, $dayOfWeek)
    {
        return $query->where('day_of_week', $dayOfWeek);
    }

    
    public function getDayNameAttribute()
    {
        return self::DAYS[$this->day_of_week] ?? 'Nieznany';
    }

    
    public function isOpenAt($time)
    {
        if ($this->is_closed) {
            return false;
        }

        
        return true;
    }

    
    public function getHoursStringAttribute()
    {
        if ($this->is_closed) {
            return 'Zamknięte';
        }

        return $this->open_time . ' - ' . $this->close_time;
    }

    
    public function canReserveAt($time, $minimumAdvanceHours = 2)
    {
        return $this->isOpenAt($time);
    }

    
    public function getAvailableReservationTimes()
    {
        if ($this->is_closed) {
            return [];
        }

        
        return ['12:00', '12:30', '13:00', '13:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30'];
    }
}