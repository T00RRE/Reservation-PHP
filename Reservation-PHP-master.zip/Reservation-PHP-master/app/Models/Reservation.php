<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class Reservation extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'restaurant_id',
        'table_id',
        'reservation_date',
        'reservation_time',
        'guests_count',
        'status',
        'special_requests',
        'notes',
        'confirmed_at',
        'cancelled_at',
    ];

    protected $casts = [
        'reservation_date' => 'date',
        'guests_count' => 'integer',
        'confirmed_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    
    const STATUS_PENDING = 'pending';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_COMPLETED = 'completed';

    
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    
    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    
    public function table(): BelongsTo
    {
        return $this->belongsTo(Table::class);
    }

    
    public function scopeActive($query)
    {
        return $query->whereNotIn('status', [self::STATUS_CANCELLED]);
    }

    
    public function scopeToday($query)
    {
        return $query->where('reservation_date', Carbon::today());
    }

    
    public function scopeUpcoming($query)
    {
        return $query->where('reservation_date', '>=', Carbon::today())
                    ->where('status', '!=', self::STATUS_CANCELLED);
    }

    
    public function confirm()
    {
        $this->update([
            'status' => self::STATUS_CONFIRMED,
            'confirmed_at' => now(),
        ]);
    }

    
    public function cancel()
    {
        $this->update([
            'status' => self::STATUS_CANCELLED,
            'cancelled_at' => now(),
        ]);
    }

    
    public function canBeCancelled()
{
    if ($this->status === 'cancelled') {
        return false;
    }

    $today = Carbon::today();
    $reservationDate = Carbon::parse($this->reservation_date);
    
    return $reservationDate->gte($today);
}

    
    public function needsReminder()
    {
        
        return $this->status === self::STATUS_CONFIRMED;
    }

    
    public static function getStatuses()
    {
        return [
            self::STATUS_PENDING => 'Oczekująca',
            self::STATUS_CONFIRMED => 'Potwierdzona',
            self::STATUS_CANCELLED => 'Anulowana',
            self::STATUS_COMPLETED => 'Zakończona',
        ];
    }
}