<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Review extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'restaurant_id',
        'dish_id',
        'rating',
        'comment',
        'is_approved',
        'approved_at',
    ];

    protected $casts = [
        'rating' => 'integer',
        'is_approved' => 'boolean',
        'approved_at' => 'datetime',
    ];

    
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    
    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    
    public function dish(): BelongsTo
    {
        return $this->belongsTo(Dish::class);
    }

    
    public function scopeApproved($query)
    {
        return $query->where('is_approved', true);
    }

    
    public function scopePending($query)
    {
        return $query->where('is_approved', false);
    }

    
    public function scopeForRestaurants($query)
    {
        return $query->whereNotNull('restaurant_id')->whereNull('dish_id');
    }

    
    public function scopeForDishes($query)
    {
        return $query->whereNotNull('dish_id')->whereNull('restaurant_id');
    }

    /**
     * Scope - sortowanie według daty (najnowsze pierwsze)
     */
    public function scopeLatest($query)
    {
        return $query->orderBy('created_at', 'desc');
    }

    /**
     * Zatwierdź opinię
     */
    public function approve()
    {
        $this->update([
            'is_approved' => true,
            'approved_at' => now(),
        ]);

        
        $this->updateAverageRating();
    }

    /**
     * Odrzuć opinię
     */
    public function reject()
    {
        $this->update([
            'is_approved' => false,
            'approved_at' => null,
        ]);
    }

    /**
     * Aktualizuj średnią ocenę restauracji lub dania
     */
    private function updateAverageRating()
    {
        if ($this->restaurant_id) {
            
            $avgRating = $this->restaurant->reviews()->approved()->avg('rating');
            $this->restaurant->update(['rating' => round($avgRating, 1)]);
        }

        if ($this->dish_id) {
            
            $avgRating = $this->dish->reviews()->approved()->avg('rating');
            $this->dish->update(['rating' => round($avgRating, 1)]);
        }
    }

    /**
     * Pobierz gwiazdki jako string
     */
    public function getStarsAttribute()
    {
        return str_repeat('★', $this->rating) . str_repeat('☆', 5 - $this->rating);
    }

    /**
     * Sprawdź czy opinia może być edytowana
     */
    public function canBeEdited()
    {
        
        return !$this->is_approved && $this->created_at->diffInHours(now()) < 24;
    }
}